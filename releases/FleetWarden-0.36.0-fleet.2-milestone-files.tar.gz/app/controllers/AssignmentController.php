<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\View;
use App\Services\AssetAssignmentService;
use App\Services\AuditService;
use Throwable;

final class AssignmentController
{
    public function index(): void
    {
        Auth::requireRole('owner', 'administrator', 'office', 'crew_leader');
        $db = Database::connection();

        $status = strtolower(trim((string) ($_GET['status'] ?? 'active')));
        if (!in_array($status, ['active', 'overdue', 'history', 'all'], true)) {
            $status = 'active';
        }
        $scope = strtolower(trim((string) ($_GET['scope'] ?? '')));
        $targetType = strtolower(trim((string) ($_GET['target_type'] ?? '')));
        $q = trim((string) ($_GET['q'] ?? ''));

        $sql = "SELECT aa.*,
            a.display_name asset_name,a.asset_tag,a.asset_type,
            ta.display_name target_asset_name,tv.unit_number target_vehicle_unit,
            tu.name target_user_name,tl.name target_location_name,td.name target_department_name,tc.name target_crew_name,
            abu.name assigned_by_name,ebu.name ended_by_name,
            CASE aa.target_type
                WHEN 'vehicle' THEN CONCAT(COALESCE(tv.unit_number,ta.asset_tag),' - ',ta.display_name)
                WHEN 'asset' THEN ta.display_name
                WHEN 'user' THEN tu.name
                WHEN 'location' THEN tl.name
                WHEN 'department' THEN td.name
                WHEN 'crew' THEN tc.name
                ELSE 'Unknown'
            END target_label
            FROM asset_assignments aa
            JOIN assets a ON a.id=aa.asset_id
            LEFT JOIN assets ta ON ta.id=aa.target_asset_id
            LEFT JOIN vehicles tv ON tv.asset_id=ta.id
            LEFT JOIN users tu ON tu.id=aa.target_user_id
            LEFT JOIN fleet_locations tl ON tl.id=aa.target_location_id
            LEFT JOIN departments td ON td.id=aa.target_department_id
            LEFT JOIN crews tc ON tc.id=aa.target_crew_id
            LEFT JOIN users abu ON abu.id=aa.assigned_by
            LEFT JOIN users ebu ON ebu.id=aa.ended_by
            WHERE 1=1";
        $bind = [];

        if ($status === 'active') {
            $sql .= ' AND aa.ended_at IS NULL';
        } elseif ($status === 'overdue') {
            $sql .= ' AND aa.ended_at IS NULL AND aa.expected_return_at IS NOT NULL AND aa.expected_return_at<NOW()';
        } elseif ($status === 'history') {
            $sql .= ' AND aa.ended_at IS NOT NULL';
        }
        if ($scope !== '') {
            $sql .= ' AND aa.assignment_scope=?';
            $bind[] = $scope;
        }
        if ($targetType !== '') {
            $sql .= ' AND aa.target_type=?';
            $bind[] = $targetType;
        }
        if ($q !== '') {
            $like = '%' . $q . '%';
            $sql .= " AND (a.display_name LIKE ? OR a.asset_tag LIKE ? OR ta.display_name LIKE ? OR tv.unit_number LIKE ? OR tu.name LIKE ? OR tl.name LIKE ? OR td.name LIKE ? OR tc.name LIKE ?)";
            array_push($bind, $like, $like, $like, $like, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY aa.ended_at IS NULL DESC, (aa.expected_return_at IS NOT NULL AND aa.expected_return_at<NOW() AND aa.ended_at IS NULL) DESC, aa.started_at DESC, aa.id DESC LIMIT 500';
        $stmt = $db->prepare($sql);
        $stmt->execute($bind);

        $stats = [
            'active' => (int) $db->query('SELECT COUNT(*) FROM asset_assignments WHERE ended_at IS NULL')->fetchColumn(),
            'overdue' => (int) $db->query('SELECT COUNT(*) FROM asset_assignments WHERE ended_at IS NULL AND expected_return_at IS NOT NULL AND expected_return_at<NOW()')->fetchColumn(),
            'on_vehicles' => (int) $db->query("SELECT COUNT(*) FROM asset_assignments WHERE ended_at IS NULL AND assignment_scope='placement' AND target_type='vehicle'")->fetchColumn(),
            'in_custody' => (int) $db->query("SELECT COUNT(*) FROM asset_assignments WHERE ended_at IS NULL AND assignment_scope IN ('custody','operator') AND target_type='user'")->fetchColumn(),
        ];

        View::render('portal/assignments/index', [
            'title' => 'Assignments',
            'rows' => $stmt->fetchAll(),
            'stats' => $stats,
            'filters' => ['status' => $status, 'scope' => $scope, 'target_type' => $targetType, 'q' => $q],
            'assets' => $db->query("SELECT id,asset_type,asset_tag,display_name FROM assets WHERE status<>'retired' ORDER BY asset_type,display_name")->fetchAll(),
            'vehicles' => $db->query("SELECT a.id,v.unit_number,a.display_name FROM assets a JOIN vehicles v ON v.asset_id=a.id WHERE v.status<>'retired' ORDER BY v.unit_number")->fetchAll(),
            'users' => $db->query("SELECT id,name,job_title FROM users WHERE status='active' ORDER BY name")->fetchAll(),
            'locations' => $db->query('SELECT id,name FROM fleet_locations WHERE active=1 ORDER BY name')->fetchAll(),
            'departments' => $db->query('SELECT id,name FROM departments WHERE active=1 ORDER BY name')->fetchAll(),
            'crews' => $db->query('SELECT id,name FROM crews WHERE active=1 ORDER BY name')->fetchAll(),
            'preselectAssetId' => (int) ($_GET['asset_id'] ?? 0),
        ], 'portal');
    }

    public function store(): void
    {
        Auth::requireRole('owner', 'administrator', 'office', 'crew_leader');
        verify_csrf();
        $db = Database::connection();
        $db->beginTransaction();
        try {
            $assignmentId = AssetAssignmentService::assign($db, [
                'asset_id' => $_POST['asset_id'] ?? null,
                'assignment_scope' => $_POST['assignment_scope'] ?? null,
                'assignment_mode' => $_POST['assignment_mode'] ?? 'permanent',
                'target_type' => $_POST['target_type'] ?? null,
                'target_id' => $_POST['target_' . ($_POST['target_type'] ?? '') . '_id'] ?? ($_POST['target_id'] ?? null),
                'started_at' => $_POST['started_at'] ?? null,
                'expected_return_at' => $_POST['expected_return_at'] ?? null,
                'condition_out' => $_POST['condition_out'] ?? null,
                'notes' => $_POST['notes'] ?? null,
                'assigned_by' => Auth::id(),
                'source' => 'portal',
            ]);
            $db->commit();
            AuditService::log('asset.assignment.started', 'asset_assignment', $assignmentId, [
                'asset_id' => (int) ($_POST['asset_id'] ?? 0),
                'target_type' => (string) ($_POST['target_type'] ?? ''),
            ]);
            flash('success', 'Asset assignment saved. Any prior assignment in the same scope was closed as a transfer.');
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            flash('danger', 'Unable to save assignment: ' . $e->getMessage());
        }
        $this->redirectBack('/portal/assignments');
    }

    public function end(string $id): void
    {
        Auth::requireRole('owner', 'administrator', 'office', 'crew_leader');
        verify_csrf();
        $db = Database::connection();
        $db->beginTransaction();
        try {
            AssetAssignmentService::end($db, (int) $id, [
                'ended_at' => $_POST['ended_at'] ?? null,
                'condition_in' => $_POST['condition_in'] ?? null,
                'return_notes' => $_POST['return_notes'] ?? null,
                'ended_by' => Auth::id(),
                'source' => 'portal',
            ]);
            $db->commit();
            AuditService::log('asset.assignment.ended', 'asset_assignment', (int) $id);
            flash('success', 'Assignment closed.');
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            flash('danger', 'Unable to close assignment: ' . $e->getMessage());
        }
        $this->redirectBack('/portal/assignments');
    }

    private function redirectBack(string $fallback): never
    {
        $returnTo = trim((string) ($_POST['return_to'] ?? ''));
        if ($returnTo !== '' && str_starts_with($returnTo, '/portal/')) {
            redirect($returnTo);
        }
        redirect($fallback);
    }
}
