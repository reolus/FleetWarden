<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\View;
use App\Services\AssetAssignmentService;
use App\Services\FleetAssetService;

final class AssetController
{
    public function index(): void
    {
        Auth::requireRole('owner', 'administrator', 'office', 'crew_leader');
        $db = Database::connection();
        $rows = $db->query("SELECT a.*,d.name department_name,l.name location_name,
            v.id vehicle_id,v.unit_number,v.year,v.make,v.model,v.vehicle_class,v.primary_meter_type,
            ea.id equipment_id,ea.category,ea.manufacturer,ea.model equipment_model,ea.serial_number,ea.condition_status
            FROM assets a
            LEFT JOIN departments d ON d.id=a.department_id
            LEFT JOIN fleet_locations l ON l.id=a.location_id
            LEFT JOIN vehicles v ON v.asset_id=a.id
            LEFT JOIN equipment_assets ea ON ea.asset_id=a.id
            ORDER BY a.asset_type,a.display_name")->fetchAll();
        $meters = FleetAssetService::latestMetersForAssets(array_column($rows, 'id'));
        $assignments = AssetAssignmentService::activeForAssets($db, array_column($rows, 'id'));
        View::render('portal/assets/index', [
            'title' => 'Assets',
            'assets' => $rows,
            'meters' => $meters,
            'assignments' => $assignments,
        ], 'portal');
    }

    public function show(string $id): void
    {
        Auth::requireLogin();
        $db = Database::connection();
        $q = $db->prepare("SELECT a.*,d.name department_name,l.name location_name,
            v.id vehicle_id,v.unit_number,v.year,v.make,v.model,v.trim,v.vehicle_class,v.vin,v.plate,v.registration_expiration,v.fuel_type,v.tank_capacity,v.gvwr,v.primary_meter_type,v.status vehicle_status,
            ea.id equipment_id,ea.category,ea.manufacturer,ea.model equipment_model,ea.serial_number,ea.condition_status,ea.warranty_expiration,ea.replacement_target_date
            FROM assets a
            LEFT JOIN departments d ON d.id=a.department_id LEFT JOIN fleet_locations l ON l.id=a.location_id
            LEFT JOIN vehicles v ON v.asset_id=a.id LEFT JOIN equipment_assets ea ON ea.asset_id=a.id
            WHERE a.id=? LIMIT 1");
        $q->execute([(int) $id]);
        $asset = $q->fetch();
        if (!$asset) {
            http_response_code(404);
            exit('Asset not found');
        }

        $m = $db->prepare("SELECT m.*,u.name recorded_name FROM asset_meter_readings m LEFT JOIN users u ON u.id=m.recorded_by WHERE m.asset_id=? ORDER BY m.reading_at DESC,m.id DESC LIMIT 100");
        $m->execute([(int) $id]);
        $events = $db->prepare("SELECT e.*,u.name actor_name FROM asset_events e LEFT JOIN users u ON u.id=e.actor_user_id WHERE e.asset_id=? ORDER BY e.occurred_at DESC,e.id DESC LIMIT 100");
        $events->execute([(int) $id]);

        $activeAssignments = AssetAssignmentService::activeForAsset($db, (int) $id);
        $assignmentHistory = AssetAssignmentService::historyForAsset($db, (int) $id, 100);
        $assignedAssets = $asset['asset_type'] === 'vehicle'
            ? AssetAssignmentService::assignedAssetsForVehicle($db, (int) $id)
            : [];

        $canAssign = Auth::can('owner', 'administrator', 'office', 'crew_leader');
        $targets = [];
        if ($canAssign) {
            $targets = [
                'assets' => $db->query("SELECT id,asset_type,asset_tag,display_name FROM assets WHERE status<>'retired' ORDER BY asset_type,display_name")->fetchAll(),
                'vehicles' => $db->query("SELECT a.id,v.unit_number,a.display_name FROM assets a JOIN vehicles v ON v.asset_id=a.id WHERE v.status<>'retired' ORDER BY v.unit_number")->fetchAll(),
                'users' => $db->query("SELECT id,name,job_title FROM users WHERE status='active' ORDER BY name")->fetchAll(),
                'locations' => $db->query('SELECT id,name FROM fleet_locations WHERE active=1 ORDER BY name')->fetchAll(),
                'departments' => $db->query('SELECT id,name FROM departments WHERE active=1 ORDER BY name')->fetchAll(),
                'crews' => $db->query('SELECT id,name FROM crews WHERE active=1 ORDER BY name')->fetchAll(),
            ];
        }

        View::render('portal/assets/show', [
            'title' => $asset['display_name'],
            'asset' => $asset,
            'readings' => $m->fetchAll(),
            'events' => $events->fetchAll(),
            'activeAssignments' => $activeAssignments,
            'assignmentHistory' => $assignmentHistory,
            'assignedAssets' => $assignedAssets,
            'canAssign' => $canAssign,
            'assignmentTargets' => $targets,
            'scanned' => !empty($_GET['scanned']),
        ], 'portal');
    }
}
