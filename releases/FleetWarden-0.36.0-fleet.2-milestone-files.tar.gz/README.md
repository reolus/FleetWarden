# FleetWarden

FleetWarden is a fleet and equipment management platform by McCartney Systems, LLC, built from the FieldWarden application platform.

Current development milestone: **0.36.0-fleet.2 - Assignments & Custody**.

Milestone 2 adds canonical assignment history for serialized assets, vehicle/equipment/user/location/department/crew placement and custody, transfers and returns, current-placement/custodian views, FleetWarden mobile "My Fleet" workflows, QR scanning, canonical asset events, and assignment health monitoring. It replaces new writes to the legacy `equipment_custody` workflow while preserving compatible historical records.

See:

- `docs/FLEETWARDEN_M2_ARCHITECTURE.md`
- `docs/FLEETWARDEN_M2_UPGRADE.md`
- `docs/FLEETWARDEN_M2_MANIFEST.md`
- `CHANGELOG-FLEETWARDEN.md`

## Baseline

- PHP 8.2+
- MySQL 8.x
- Apache
- FleetWarden 0.35.0-fleet.1 / FieldWarden 0.34.x-compatible database history
- Optional Microsoft Entra ID / Microsoft 365 integrations

## Upgrade

Back up the application and database, deploy the release files, then run:

```bash
php scripts/migrate.php status
php scripts/migrate.php migrate
php scripts/migrate.php status
php tests/phase36_0_regression.php
php tests/phase35_0_regression.php
php tests/route_validation.php
php tests/smoke.php
```

For the fictional Brighthaven demo environment only, optionally load `database/demo/seed_fleetwarden_m2_brighthaven.sql` after the migrations to add serialized equipment and assignment examples.

Database execution must be validated on the target MySQL environment. The release build environment performs static source/schema reconciliation, PHP validation, regression/static tests, and route validation; it does not pretend a MySQL server existed where one did not.
